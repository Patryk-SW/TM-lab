#include "RPILAB.h"
#include "bcm2836.h"
#include <stdlib.h>

typedef struct
{
short int x,y,dx,dy,s;
} square_t;


//void draw_rect(unsigned char* FB, unsigned int pitch, int x, int y, int width, int height ,unsigned int val);
void fade_screen(unsigned long* FB, unsigned long* back, unsigned int pitch, int height);
void InitData();
void InitHardware();
void GPIOHandle();
void scroll_screen(int y_offset);
void draw_pixel(unsigned char* FB, unsigned int pitch, int x, int y, unsigned int color);
void zmien_tlo(unsigned char *FB, unsigned int pitch,unsigned int width, unsigned int height, unsigned int kolor);
