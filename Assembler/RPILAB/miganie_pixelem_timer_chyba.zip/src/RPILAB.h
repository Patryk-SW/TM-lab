#define screen_width 600
#define screen_height 480
#define max_height 1000
#define max_width 1000
#define screen_depth 32
#define virtual_width (screen_width+40)
#define virtual_height (screen_height*2)
#define virtual_word_pitch virtual_width

#define Q_MATH 3
#define max_obj 500

#define screen_Qwidth (screen_width<<Q_MATH)
#define screen_Qheight (screen_height<<Q_MATH)

#define BLUE 0x0000FF
#define RED 0xFF0000
#define GREEN 0x00FF00
#define YELLOW 0xFFFF00

#ifndef __ASM__
extern unsigned int _mb_msg;
extern unsigned int _fb_addr;
extern unsigned int _fb_pitch;

void MBarrier();
void STR(unsigned int, unsigned int);
unsigned int LDR(unsigned int);
void irq_enable();
void irq_disable();
#endif
