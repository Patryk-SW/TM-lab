#include "main.h"

//Zmienne kontrolujące stan pracy oprogramowania
int time_stamp, fade_step, fade_start_place;

//Tablica struktur informacji o kwadratach rysowanych na LCD
square_t kwadraty[max_obj];

unsigned char *fb_addr; 	// Wskaźnik na famebuffer
unsigned int fb_pitch;		// Szerokośc wiersza framebuffera wyrazona w bajtach
// Bufory pomocnicze przechowujące obrazy tła
unsigned long backgroundB[max_height * max_width];
unsigned long backgroundR[max_height * max_width];
unsigned long background1[virtual_height*virtual_word_pitch];
unsigned long background2[virtual_height*virtual_word_pitch];
//unsigned long tlo1[max_width * max_height];
//unsigned long tlo2[max_width * max_height];
//unsigned int offsetY;
//unsigned int licznik;

int stop;
int screen_yoffset_counter;
int screen_yoffset;

enum FB_BufferVisibility_t {FB_ScreenA,FB_ScreenB,FB_ScrollingToA,FB_ScrollingToB};
enum FB_BufferVisibility_t FB_BufferVisibility;

extern unsigned int _mb_virt_offset_msg;
extern unsigned int _v_X;
extern unsigned int _v_Y;
extern unsigned int _v_request;
extern unsigned int _v_answer;

// Do obsługi migającego piksela
volatile int pixel_blink_active = 0;
volatile int pixel_blink_timer = 0;
extern void asm_counter_tick(void);

extern void reinit_irq(void);           // deklaracja funkcji asemblerowej
extern unsigned int get_fb_offset(int); // deklaracja funkcji asemblerowej

void test_reinit_irq_and_fb_offset()
{
    // PRZYKŁAD 1: Reinicjalizacja przerwania (np. po obsłudze IRQ lub na starcie)
    reinit_irq();

    // PRZYKŁAD 2: Wyznaczanie offsetu pionowego framebuffer-a dla wybranego wiersza
    int y = 100; // np. 100-ty wiersz
    unsigned int offset = get_fb_offset(y);

    // Przykład użycia: ustaw piksel na środku wiersza y na czerwony
    int x = screen_width / 2;
    unsigned int *pixel_ptr = (unsigned int *)(fb_addr + offset + x * 4);
    *pixel_ptr = 0xFF0000; // czerwony
}


//Punkt wejścia do języka C (procedura wywoływnana z asemblera)
void notmain(void) {
	FB_BufferVisibility=FB_ScreenA;
	STR(STC1,LDR(STCLO) + IntTimerPeriod);
	STR(IRQEN1,2);
	screen_yoffset_counter=0;
	screen_yoffset=0;
	InitHardware();		// Inicjalizacja sprzętu
	InitData();			// inicjalizacja danych
	irq_enable();
	unsigned int fb_width_px=fb_pitch/4;
	for (unsigned long idx=0;idx<fb_width_px*virtual_height/2;idx++){
		background1[idx]=255UL*idx/(fb_width_px*screen_height);
		background1[idx+fb_width_px*virtual_height/2]=(255UL*idx/(fb_width_px*screen_height))<<16;
	}
	time_stamp=0;
	test_reinit_irq_and_fb_offset();
       while (1) {
    	   // Obsługa migającego piksela
    	   		if (pixel_blink_active) {
    	   			pixel_blink_timer++;
    	   			if (pixel_blink_timer == 1000) { // "500" odpowiada 0,5 sekundy, musisz dobrać do swojego zegara!
    	   				draw_pixel(fb_addr, fb_pitch, screen_width / 2, screen_height / 2, 0xFFb0000); // Zgaś piksel
    	   				pixel_blink_active = 0;
    	   				pixel_blink_timer = 0;
    	   			}
    	   		}

    	   		// Co sekundę (symulacja, możesz wywołać przez przerwanie timera)
    	   		static int sec_counter = 0;
    	   		sec_counter++;
    	   		if (sec_counter >= 3000) { // "1000" oznacza 1 sekundę – dostosuj do swojego systemu!
    	   			sec_counter = 0;
    	   			asm_counter_tick(); // Wywołanie licznika i zapalenie piksela na 0,5s
    	   		}

    	   		// Tu inne funkcje...
    	   		GPIOHandle();
    	   	}}

// W przerwaniu lub w funkcji wywoływanej co 0,5 sekundy (np. z timera 500ms):
void half_second_tick() {
    static int on = 0;
    if (on) {
        // zgaś piksel (np. czarny kolor)
        draw_pixel(fb_addr, fb_pitch, screen_width/2, screen_height/2, 0x000000);
        on = 0;
    } else {
        on = 1;
    }
}

void ClearScreen()
{
	fade_screen((unsigned long*) fb_addr, background1, fb_pitch, virtual_height); //wygasza iteracyjnie ekran
}


void scroll_screen(int y_offset)
{
	*((unsigned int*)(&_v_X))=0;  //*4 dla QEMY - bug?
	*((unsigned int*)(&_v_Y))=y_offset*4;
	*((unsigned int*)(&_v_request))=0;
	*((unsigned int*)(&_v_answer))=0;
	ExchangeMB((unsigned int) &_mb_virt_offset_msg | 8);
}
//zmienia cale tlo na jeden kolor
void zmien_tlo(unsigned char *FB, unsigned int pitch,unsigned int width, unsigned int height, unsigned int kolor){
	for(int y=0; y<height;y++){
		for(int x=0; x<width; x++){ //wypelnia cala linie w danym kolorze i przechodzi do kolejnej linii
			unsigned int* pixel=(unsigned int*)(FB+x*4+y*pitch); //zmienna wskaźnikowa ktora przechowuje adres pierwszej komorki kazdego pixela
			*pixel=kolor;
		}
	}
}



//--------------------------------------------------------------------------------
//                                     PROCEDURY
//--------------------------------------------------------------------------------

//Inicjalizacja danych globalnych
void InitData() {
	fade_step = 18, fade_start_place = 0; // Ustaw czyszczenie ekranu na 18 iteracji
	time_stamp=0;						  // Zerowanie znacznika czasowego
}

//Inicjalizacja układów peryferyjnych
void InitHardware() {
	STR(GPFSEL3, 1 << 15); // gpio35 ustawiony na wyjście
	ExchangeMB((int) &_mb_msg | 8); // Wymiana wiadomości na kanale 8 - ustawienie framebuffer-a
	fb_addr = (unsigned char*) (*(&_fb_addr) & 0x3fffffff); //adres framebuffer-a
	fb_pitch = (unsigned int) (*(&_fb_pitch)); //skok wiersza framebuffer-a
}

// Iteracyjne czyszczenie framebuffer-a na podstawie stanu portu GPIO35


//Wysterowuje porty GPIO35 na podstawie upływu czasu
void GPIOHandle() {
	if (time_stamp&0x1200)
		STR(GPSET1, 1 << (35 - 32)); // Ustaw na jedynkę GPIO35
	else
		STR(GPCLR1, 1 << (35 - 32)); // Wyzeruj GPIO35

}

// Rysuje sumą logiczną prostokąt o podanych parametrach


void fade_screen(unsigned long *FB, unsigned long *back, unsigned int pitch, int height) {

// Wyznaczenie iteracji wygaszania zawartości framebuffer-au
	fade_start_place++;
	if (fade_start_place > fade_step) {
		fade_start_place = 0;
		fade_step ^= 0x1;
	}
	FB = &FB[fade_start_place];
	back = &back[fade_start_place];


//Wygaszanie i nakładanie tła we framebuferze dla wyznaczobej iteracji
	int pixInRow = pitch / 4;
	for (unsigned int idx = 0; idx < pixInRow * height; idx += fade_step) {
		*FB = ((*FB & 0xfe00) >> 1) | *back;
		FB += fade_step;
		back += fade_step;
	}

}

//Rysuje obiekty we framebuferze

//Procedura obsługi przerwania IRQ
void handler_irq() {
	STR(STC1,LDR(STCLO)+IntTimerPeriod);
	STR(STCS,2);

	/*if(FB_BufferVisibility==FB_ScrollingToB)
	{
		screen_yoffset_counter++;
		if(screen_yoffset_counter>=1000){
			screen_yoffset_counter=1000;
			FB_BufferVisibility=FB_ScreenB;
		}
	}
	else if(FB_BufferVisibility==FB_ScrollingToA){
		screen_yoffset_counter--;
			if(screen_yoffset_counter<=0){
				screen_yoffset_counter=0;
				FB_BufferVisibility=FB_ScreenA;
			}
	}
	screen_yoffset=screen_height*screen_yoffset_counter/1000;*/
}
// Funkcja wywoływana z ASM – zapala piksel na środku ekranu na 0,5s
void blink_center_pixel(void) {
	draw_pixel(fb_addr, fb_pitch, screen_width/2, screen_height/2, 0x00FF00);
	pixel_blink_active = 1;
	pixel_blink_timer = 0;
}
