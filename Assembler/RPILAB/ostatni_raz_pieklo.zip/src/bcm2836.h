#define MBOXREAD 0x3f00B880
#define MBOXSTAT 0x3f00B898
#define MBOXWRTE 0x3f00B8A0

#define GPFSEL0  0x3f200000
#define GPFSEL3  0x3f20000C
#define GPFSEL4  0x3f200010
#define GPSET1   0x3f200020
#define GPCLR1   0x3f20002C
#define GPLEV1   0x3f200038

#define GPLEV0   0x3f200034

#define GPFSEL1  0x3f200004
#define IRQPEND1 0x3f00B204
#define IRQEN1 	 0x3f00B21C
#define IRQDIS1  0x3f00B21C
#define GPSET0 	 0x3f20001C
#define GPCLR0 	 0x3f200028
#define STCS 	 0x3f003000
#define STCHI 	 0x3f003008
#define STC1 	 0x3f003010
#define STCLO 	 0x3f003004
#define IntTimerPeriod 100

void ExchangeMB(int msg);
