#include "RPILAB.h"
#include "bcm2836.h"
#include <stdlib.h>

typedef struct
{
	short int x, y, dx, dy, s;
} square_t;

void fade_screen(unsigned long* FB, unsigned long* back, unsigned int pitch, int height);
void InitData();
void InitHardware();
void GPIOHandle();
void scroll_screen(int y_offset);

void draw_pixel(unsigned char* FB, unsigned int pitch, int x, int y, unsigned int color);

// Funkcja wywoływana z ASM do zapalania piksela na środku
void blink_center_pixel(void);

// Dodane deklaracje do zadania lab. 10:
void reinit_irq(void);
unsigned int get_fb_offset(int y);
