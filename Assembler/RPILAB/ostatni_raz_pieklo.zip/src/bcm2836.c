#include "bcm2836.h"
#include "RPILAB.h"


void ExchangeMB(int msg) {
	do {
		MBarrier();
		} while (LDR(MBOXSTAT) & 1 << 31);    // powtarzaj jeśli MB pełny
	MBarrier();
	STR(MBOXWRTE, msg | 8);
	do {
		do {
			MBarrier();
			} while (LDR(MBOXSTAT) & 1 << 30); // powtarzaj jeśli MB pusty
		MBarrier();
		} while ((LDR(MBOXREAD) & 0x0f) != (msg & 0x0f) ); // powtarzaj jesli nadeszła odpowiedż dla niewłaściwego kanału
}
